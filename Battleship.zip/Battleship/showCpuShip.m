function [board_display] = showCpuShip(ship_id, board_display, cpu_ships, left_ship_sprite, right_ship_sprite, horiz_ship_sprite, top_ship_sprite, bot_ship_sprite)
%showCpuShips Adds the cpu ships to the board_display

% Show the carrier (length 5)
if ship_id == 1
    
    found = false;
    
    while ~found
        
        % Find ships
        
    end
end

if ship_id == 2
    
    found = false;
    
    while ~found
        
        
    end
    
    
end
        
    
if ship_id == 3
    
    found = false;
    
    while ~found
        
        
    end
    
    
end


if ship_id == 4
    
    found = false
    
    % Copy code from ship 3
    
    
end

if ship_id == 5
    
    found = false;
    
    while ~found
        
        
    end
    
end
    
    
    
    
    


end

